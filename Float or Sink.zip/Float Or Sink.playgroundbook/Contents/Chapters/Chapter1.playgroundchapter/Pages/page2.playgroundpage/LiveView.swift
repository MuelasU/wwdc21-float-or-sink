import FloatOrSink
import PlaygroundSupport

PlaygroundPage.current.setLiveView(SandboxPratice())
