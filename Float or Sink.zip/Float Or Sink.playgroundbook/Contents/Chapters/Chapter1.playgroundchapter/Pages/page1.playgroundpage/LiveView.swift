import PlaygroundSupport
import FloatOrSink

PlaygroundPage.current.setLiveView(TheoricalConcepts())
